import express from 'express'
import multer from 'multer'
import ytDlp from 'yt-dlp-exec'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { randomUUID } from 'node:crypto'
import { spawn } from 'node:child_process'

const app = express()
const port = Number(process.env.PORT || 8787)
const allowedHosts = ['youtube.com', 'youtu.be', 'tiktok.com', 'facebook.com', 'fb.watch', 'instagram.com']
const upload = multer({ storage: multer.memoryStorage(), limits: { files: 10, fileSize: 100 * 1024 * 1024 } })

app.use(express.json({ limit: '20kb' }))

const runFfmpeg = (args) => new Promise((resolve, reject) => { const process = spawn('ffmpeg', args, { windowsHide: true }); let error = ''; process.stderr.on('data', (chunk) => { error += chunk.toString() }); process.on('close', (code) => code === 0 ? resolve() : reject(new Error(error.slice(-600) || `ffmpeg exited with ${code}`))) })

const validateUrl = (value) => {
  try {
    const parsed = new URL(value)
    const host = parsed.hostname.replace(/^www\./, '')
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return null
    return allowedHosts.some((allowed) => host === allowed || host.endsWith(`.${allowed}`)) ? parsed.toString() : null
  } catch { return null }
}

const platformName = (url) => {
  const host = new URL(url).hostname.replace(/^www\./, '')
  if (host.includes('youtube') || host === 'youtu.be') return 'YouTube'
  if (host.includes('tiktok')) return 'TikTok'
  if (host.includes('facebook') || host === 'fb.watch') return 'Facebook'
  return 'Instagram'
}

const getInfo = async (url) => ytDlp(url, { dumpSingleJson: true, noWarnings: true, noPlaylist: true, skipDownload: true })

app.post('/api/metadata', async (req, res) => {
  const url = validateUrl(req.body?.url)
  if (!url) return res.status(400).json({ error: 'Link không hợp lệ hoặc nền tảng chưa được hỗ trợ.' })
  try {
    const info = await getInfo(url)
    return res.json({ title: info.title || 'Video không tên', thumbnail: info.thumbnail || '', duration: info.duration || 0, uploader: info.uploader || '', platform: platformName(url), url })
  } catch (error) {
    console.error('metadata error:', error.shortMessage || error.message)
    return res.status(502).json({ error: 'Không đọc được video. Hãy kiểm tra link có công khai và thử lại.' })
  }
})

app.post('/api/extract', async (req, res) => {
  const url = validateUrl(req.body?.url)
  if (!url) return res.status(400).json({ error: 'Link không hợp lệ hoặc nền tảng chưa được hỗ trợ.' })
  const quality = ['128', '256', '320'].includes(String(req.body?.quality)) ? String(req.body.quality) : '320'
  const tempFile = path.join(os.tmpdir(), `minhan-${randomUUID()}.mp3`)
  try {
    const info = await getInfo(url)
    const title = info.title || 'minhan-editer'
    await ytDlp(url, { extractAudio: true, audioFormat: 'mp3', audioQuality: quality, noPlaylist: true, output: tempFile, noWarnings: true })
    if (!fs.existsSync(tempFile)) throw new Error('Không tạo được file MP3')
    const safeName = title.replace(/[<>:"/\\|?*\x00-\x1F]/g, '').replace(/\s+/g, ' ').trim().slice(0, 150) || 'minhan-editer'
    res.download(tempFile, `${safeName}.mp3`, (error) => { fs.rm(tempFile, { force: true }, () => {}); if (error && !res.headersSent) res.status(500).json({ error: 'Không thể gửi file MP3.' }) })
  } catch (error) {
    fs.rm(tempFile, { force: true }, () => {})
    console.error('extract error:', error.shortMessage || error.message)
    return res.status(502).json({ error: 'Không thể chuyển video này thành MP3. Chỉ dùng nội dung bạn có quyền tải.' })
  }
})

app.post('/api/mp4', async (req, res) => {
  const url = validateUrl(req.body?.url)
  if (!url) return res.status(400).json({ error: 'Link không hợp lệ hoặc nền tảng chưa được hỗ trợ.' })
  const quality = String(req.body?.quality || 'best')
  const format = quality === 'best' ? 'bestvideo*+bestaudio/best' : `bestvideo[height<=${['1080', '720', '480'].includes(quality) ? quality : '1080'}]+bestaudio/best`
  const tempFile = path.join(os.tmpdir(), `minhan-${randomUUID()}.mp4`)
  try { const info = await getInfo(url); const title = info.title || 'minhan-editer'; await ytDlp(url, { format, mergeOutputFormat: 'mp4', noPlaylist: true, output: tempFile, noWarnings: true }); const safeName = title.replace(/[<>:"/\\|?*\x00-\x1F]/g, '').replace(/\s+/g, ' ').trim().slice(0, 150) || 'minhan-editer'; res.download(tempFile, `${safeName}.mp4`, (error) => { fs.rm(tempFile, { force: true }, () => {}); if (error && !res.headersSent) res.status(500).json({ error: 'Không thể gửi file MP4.' }) }) } catch (error) { fs.rm(tempFile, { force: true }, () => {}); console.error('mp4 error:', error.shortMessage || error.message); return res.status(502).json({ error: 'Không thể chuyển video này thành MP4. Hãy thử link công khai khác.' }) }
})

app.post('/api/mix', upload.array('files', 10), async (req, res) => {
  const files = req.files || []
  if (!files.length) return res.status(400).json({ error: 'Chưa có file audio để ghép.' })
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'minhan-mix-'))
  const inputs = files.map((file, index) => { const input = path.join(folder, `${index}-${file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_')}`); fs.writeFileSync(input, file.buffer); return input })
  const output = path.join(folder, 'minhan-studio.mp3')
  try { const volume = Math.max(0, Math.min(2, Number(req.body.volume || 100) / 100)); const start = Math.max(0, Number(req.body.start || 0)); const end = Number(req.body.end || 0); const fadeIn = req.body.fadeIn === 'true'; const fadeOut = req.body.fadeOut === 'true'; const args = ['-y']; inputs.forEach((input) => args.push('-i', input)); const filters = inputs.map((_, index) => { const trim = end > start ? `atrim=start=${start}:end=${end},` : `atrim=start=${start},`; const fade = `${fadeIn && index === 0 ? ',afade=t=in:st=0:d=1' : ''}${fadeOut && index === inputs.length - 1 ? ',areverse,afade=t=in:st=0:d=1,areverse' : ''}`; return `[${index}:a]${trim}asetpts=PTS-STARTPTS,volume=${volume}${fade}[a${index}]` }).join(';'); const concat = inputs.map((_, index) => `[a${index}]`).join(''); args.push('-filter_complex', `${filters};${concat}concat=n=${inputs.length}:v=0:a=1[out]`, '-map', '[out]', '-codec:a', 'libmp3lame', '-b:a', '320k', output); await runFfmpeg(args); res.download(output, 'minhan-studio.mp3', () => fs.rm(folder, { recursive: true, force: true }, () => {})) } catch (error) { fs.rm(folder, { recursive: true, force: true }, () => {}); console.error('mix error:', error.message); return res.status(500).json({ error: 'Không thể ghép file. Hãy thử file audio khác.' }) }
})

app.listen(port, () => console.log(`MinhAn Editer API: http://127.0.0.1:${port}`))